/*
* Autor: Jose Fernado Troyano.
* Fecha: 2025-04-04
* Descripción:  Data model to Card
* Versión: 1.0
* */
class DataCard {
  constructor() {

    this.name = 'Jose Fernando';
    this.lastNmae = 'Troyano Perenguez';
    this.postalCode = '12345';
    
  }
}

module.exports = DataCard;

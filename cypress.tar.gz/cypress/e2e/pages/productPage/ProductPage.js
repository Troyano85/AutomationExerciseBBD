/*
* Autor: Jose Fernado Troyano.
* Fecha: 2025-04-04
* Descripción:  Page Object general class to products 
* Versión: 1.0
* */
import Page from '../helperPage/Page.js'
import Assertions from '../../question/Assertions.js'

const page = new Page
const assertsThat = new Assertions

class ProductPage extends Page {
    constructor() {
        const elements = {
            productLbl: () =>  cy.get('[data-test="add-to-cart-test.allthethings()-t-shirt-(red)"]'),
            productLblSelet2: () => cy.get('[data-test="inventory-item-test.allthethings()-t-shirt-(red)-img"]'),
            // 4. Agregar el segundo producto al carrito
            productsByImages: () => cy.get('[data-test="add-to-cart-sauce-labs-bike-light"]'),
            // 5. Agregar el tercer producto al carrito
            productstrre: () => cy.get('[data-test="add-to-cart-sauce-labs-bolt-t-shirt"]'),
            // 6. Ir al carrito y verificar los productos
            addProduct: () => cy.get('.shopping_cart_link'),
            valiateProductoThreecy: () => cy.get('.cart_item'),
            // 7. Remover el primer producto agregado
            card: () => cy.get('[data-test="remove-test.allthethings()-t-shirt-(red)"]'),
            validarProductsByImages: () => cy.get('.cart_item'),
            // 8. Finalizar la compra
            checkoutRefere: () => cy.get('[data-test="checkout"]'),
            firstname: () => cy.get('[data-test="firstName"]'),
            lastName: () => cy.get('[data-test="lastName"]'),
            postalCode: () => cy.get('[data-test="postalCode"]'),
            buttonContinue: () => cy.get('[data-test="continue"]'),
            buttonFinish: () => cy.get('[data-test="finish"]'),
            validateThanks: () => cy.get('.complete-header'),
            // click en el menu hamburguesa
            burguerMenu: () => cy.get('#react-burger-menu-btn'),
            buttonLogout: () => cy.get('#logout_sidebar_link'),
            //


        }
        super(elements);

    }

    clickProductLbl() {
        this.elements.productLbl().click()
        return this;
    }

    
    clickProductsByImages() {
        this.elements.productsByImages().click()
        return this;
    }
    clickProductstrre() {
        this.elements.productstrre().click()
        return this;
    }
    clickAddProduct() {
        this.elements.addProduct().click()
        return this;
    }
    valiateProductoThreecy() {
        this.elements.valiateProductoThreecy().should('have.length', 3)
        return this;
    }
    clickCard() {
        this.elements.card().click();
        return this;
    }
    validateProductsByImages() {
        this.elements.validarProductsByImages().should('have.length', 2)
        return this;
    }
    clickCheckoutRefere() {
        this.elements.checkoutRefere().click()
        return this;
    }
    fillFirstname(text) {
        this.elements.firstname().type(text)
        return this;
    }
    fillLastName(text) {
        this.elements.lastName().type(text)
        return this;
    }
    fillPostalCode(text) {
        this.elements.postalCode().type(text)
        return this;
    }
    clickButtonContinue() {
        this.elements.buttonContinue().click()
        return this;
    }
    clickbuttonFinish() {
        this.elements.buttonFinish().click()
        return this;
    }
    validateThanks() {
        this.elements.validateThanks().should('be.visible');
        return this;
    }
    clickBurguerMenu() {
        this.elements.burguerMenu().click()
        return this;
    }
    clickButtonLogout() {
        this.elements.buttonLogout().click()
        return this;
    }


}
export default new ProductPage();
/*
* Autor: Jose Fernado Troyano.
* Fecha: 2025-04-04
* Description: Page Object general class to login
* Version: 1.0
* */
import Page from '../helperPage/Page.js'
const page = new Page



class login extends Page {


    constructor() {
        const elements = {
            // login new user 

            signupNameTxt: () => cy.get('#user-name'),
            signupEmailTxt: () => cy.get('#password'),
            signupBtn: () => cy.get('[data-test="login-button"]'),
            // login user 
            loginEmailTxt: '#user-name',
            loginPasswordTxt: '#password',
            loginButtonBtn: () => cy.get('[data-test="login-button"]'),
            loggedInAsLbl: 'Logged in as',
            validateLogin: () => cy.contains('Test.allTheThings() T-Shirt')



        }
        super(elements);
    }

    // login new user 
    fillSignupNameTxt() {
        cy.newUserNameFake().then((userName) => {
            cy.log('UserNAme:', userName);
            this.elements.signupNameTxt().clear().type(userName);
        });
        return this;
    }

    fillSignupEmailTxt() {
        cy.newEmailFake().then((email) => {
            cy.log('Email:', email);
            this.elements.signupEmailTxt().clear().type(email);
        });
        return this;
    }

    clickSignupBtn() {
        this.elements.signupBtn().click()
        return this;
    }
    // login user/admin 
    fillLoginEmailTxt(email) {
        page.forceTypesendKeyByElement(this.elements.loginEmailTxt, email);
        return this;

    }

    fillLoginPasswordTxt(password) {
        cy.get(this.elements.loginPasswordTxt).type(password, { delay: 0, force: true });
        return this;

    }
    clickLoginButtonBtn() {
        this.elements.loginButtonBtn().click()
        return this;
    }
    validateLogin() {
        this.elements.validateLogin().should('be.visible');
        return this;
    }
}
export default new login();
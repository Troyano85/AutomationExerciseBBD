/*
* Autor: Jose Fernado Troyano.
* Fecha: 2025-04-04
* Descripción:  Task class to manage card
* Versión: 1.0
* */

import PurchaseData from '../model/PurchaseUserData'
import ProductPage from '../pages/productPage/ProductPage'

const purcharseData = new PurchaseData();

const fillData = () => {
    ProductPage.fillFirstname(purcharseData.name); 
    ProductPage.fillLastName(purcharseData.lastNmae);
    ProductPage.fillPostalCode(purcharseData.postalCode); 
    ProductPage.clickButtonContinue();
    ProductPage.clickbuttonFinish();

};


export { fillData  };
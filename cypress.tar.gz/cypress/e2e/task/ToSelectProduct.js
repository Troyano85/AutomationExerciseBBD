/*
* Autor: Jose Fernado Troyano.
* Fecha: 2025-04-04
* Descripción:  General class to manage on product
* Versión: 1.0
* */

import ProductPage from '../pages/productPage/ProductPage'



const addProductCart = () => {
    ProductPage.clickProductLbl();
    ProductPage.clickProductsByImages()
    ProductPage.clickProductstrre();
   
    ProductPage.clickAddProduct();
    ProductPage.valiateProductoThreecy();
    ProductPage.clickCard();
    ProductPage.validateProductsByImages();
    ProductPage.clickCheckoutRefere();
}
export { addProductCart };
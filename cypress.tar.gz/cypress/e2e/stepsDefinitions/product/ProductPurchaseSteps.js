/*
* Autor: Jose Fernado Troyano.
* Fecha: 2025-04-04
* Descripción:  Step definition clase to general login
* Versión: 1.0
* */
import { Given, When, Then } from '@badeball/cypress-cucumber-preprocessor';
import { loginAdmin, goToPage } from '../../task/ToFilllogin.js';
import { addProductCart} from '../../task/ToSelectProduct.js';
import ProductPage from '../../pages/productPage/ProductPage.js';
import { fillData } from '../../task/ToFillDataPurche.js';

// Simulate an iPhone X before each test
 /*
beforeEach(() => {

  cy.viewport('iphone-x');
  goToPage();
});*/

Given('I am logged in the page', () => {
  goToPage();
  loginAdmin();

});


When('I select the product and I add the product to the cart', () => {
  addProductCart();
  
});


When('I proceed to logout', () => {
  ProductPage.clickBurguerMenu();
  ProductPage.clickButtonLogout();
});

When("I fill my personal data", function () {
  fillData();
  });

Then('I should see the order confirmation page', () => {
  ProductPage.validateThanks();
  
           
});






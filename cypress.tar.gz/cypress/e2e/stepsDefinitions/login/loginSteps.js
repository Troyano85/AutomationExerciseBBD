/*
* Autor: Jose Fernado Troyano.
* Fecha: 2025-04-04
* Descripción:  Step definition clase to product purchase
* Versión: 1.0
* */
import { Given, When, Then } from '@badeball/cypress-cucumber-preprocessor';
import { goToPage, loginAdmin } from '../../task/ToFilllogin.js'
import LoginPage from '../../pages/loginPage/loginPage.js'



Given('I open the login page', () => {
  goToPage();

});

When('I enter valid credentials', () => {
  loginAdmin();
});

Then('I should see Logged', () => {
  LoginPage.validateLogin();

});


